<?php
$dbservername="db";
$dbusername="hamza12";
$dbpassword="wh123";
$dbname="students_database";

$conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);
?>